# CircleUp — 30-Day Growth Plan

One milestone per day, each building on the last. Organized in five weeks-ish blocks matching `future-scope.md`'s priorities. Use `daily-build-prompt.md` each day to execute.

## Week 1: Media & Identity (Days 1–6)
1. Set up Firebase Storage; write and test upload/download service functions
2. Add image picker (`expo-image-picker`) to the Create Post flow
3. Display post images in the feed and Post Detail screen
4. Add profile picture upload on the Profile screen
5. Show profile pictures in Post/Comment author lines (currently text-only)
6. QA pass: test image upload on slow/offline connections, add upload progress/error states

## Week 2: Findability & Scale (Days 7–13)
7. Add `limit()` pagination to `subscribeToAllCircles`
8. Add "load more" UI pattern to Browse Circles
9. Add `limit()` pagination to `subscribeToCirclePosts`
10. Add "load more" to the Circle Feed
11. Build a simple client-side search/filter on circle name for the Browse screen
12. Add a "trending" or "recently active" sort option to Browse
13. QA pass: test pagination with 50+ seeded circles, verify no duplicate/missing items

## Week 3: Notifications & Engagement (Days 14–19)
14. Install and configure `expo-notifications`, request permissions
15. Send a local notification when someone comments on your post
16. Send a notification when a new post appears in a circle you've joined
17. Add a notification settings toggle per circle (mute/unmute)
18. Add a lightweight "last active" or unread indicator on My Circles
19. QA pass: test notification permission denial gracefully (app must not break)

## Week 4: Trust & Moderation (Days 20–25)
20. Add a "report post/comment" action with a Firestore `reports` collection
21. Give circle creators a way to remove a post from their circle
22. Give circle creators a way to remove a member from their circle
23. Add basic content length/rate limiting server-side (Firestore rules or Cloud Functions)
24. Write your first Jest tests for `authService.js` and `circleService.js`
25. QA pass: attempt to bypass moderation via direct Firestore calls, confirm rules hold

## Week 5: Production Maturity (Days 26–30)
26. Set up a GitHub Actions workflow running tests on every push
27. Design and add a custom app icon and splash screen
28. Write and publish an EAS Update for this month's changes; verify on a real device
29. Update README, screenshots, and portfolio materials to reflect the new feature set
30. Full end-to-end walkthrough + retrospective: what worked, what to prioritize for month two

## How to Use This

Each day, paste `daily-build-prompt.md` into a fresh session (or continue an existing one), replacing only the day number. Don't skip the QA-pass days (6, 13, 19, 25, 30) — they're deliberately placed after each themed block, matching the pattern that caught the real security issue on Day 8 of the original sprint.
