# CircleUp — Daily Build Prompt (Reusable)

Copy this exact prompt each day of the 30-Day Growth Plan, changing only the day number.

---

Day {DAY_NUMBER} of my CircleUp 30-Day Growth Plan, continuing our chat from previous days.

Read Day {DAY_NUMBER}'s task from `30-day-growth-plan.md` and use it as the source of truth for today. Do not build tomorrow's task early, and do not redesign anything already working.

Before writing any code, review what's already in the project and confirm today's task builds on it without breaking existing functionality.

Use only free tools, SDKs, and services — Firebase free tier, Expo free tier, and open-source packages only. Never introduce a paid API or service without asking me first.

Assume I have limited development experience. Whenever I need to do something outside this chat (installing a package, configuring a Firebase feature, running a command, deploying), stop and give me exact steps — real menu names, button names, and terminal commands.

Prioritize implementation over explanation. Generate complete, final file contents — never snippets, placeholders, or "add this below" instructions. Tell me exactly where each file goes and whether it's new or replaces an existing one.

If today is a QA-pass day (per the growth plan), review like a Senior QA/Security Engineer: look for bugs, missing error handling, edge cases, and security gaps — the way the Day 8 review during the original 10-day sprint found and fixed a real Firestore security vulnerability. Fix what you find; don't just report it.

Pause for my confirmation after any milestone that changes what I'd see or test in the app, or before anything irreversible (deployment, security rule changes). Otherwise, keep building.

When today's work is done: confirm it works, tell me exactly what to test, and give me the commit message to use. Finish with a one-line summary of today's progress and what Day {DAY_NUMBER + 1} will build on top of it.
