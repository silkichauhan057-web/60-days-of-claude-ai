# GitHub Metadata Recommendations & v1.0.0 Release Guide

## Repository Description (paste into the repo's "About" gear icon)

> A React Native + Firebase social app for joining interest-based circles, sharing updates, and commenting — built over a structured 10-day sprint with a real security fix along the way.

## Suggested Topics (add via the "About" gear icon, comma or space separated)

```
react-native expo firebase firestore mobile-app javascript capstone-project
social-app authentication realtime-database security prompt-engineering
```

## v1.0.0 Release — Step by Step

Once your real CircleUp source code is confirmed pushed to its repository:

1. Go to your repo on github.com.
2. Click the **"Releases"** link (right sidebar, or under the "Code" tab near the top).
3. Click **"Create a new release"** (or "Draft a new release").
4. In **"Choose a tag"**, type `v1.0.0` and click **"Create new tag: v1.0.0 on publish."**
5. **Release title:** `CircleUp v1.0.0 — Initial Public Release`
6. **Description box** — paste this:

```
CircleUp v1.0.0 — the first public release.

A React Native + Firebase mobile app for joining interest-based
communities, sharing live updates, and commenting — built end-to-end
over a structured 10-day sprint.

Highlights:
- Full authentication (signup, login, persisted sessions)
- Create, browse, join, and leave interest-based circles
- Real-time posts and comments within circles
- Production-hardened Firestore security rules (fixed a real
  authorization vulnerability found during Day 8 QA)
- Offline detection, crash recovery, and full loading/empty/error
  state coverage
- Environment-variable-based configuration (no secrets in source)

See README.md for setup instructions, challenge-retrospective.md for
the full build story, and future-scope.md for what's next.
```

7. Click **"Publish release."**

That's it — this creates a permanent, linkable `v1.0.0` snapshot of your code that you can point to from your resume or portfolio.
