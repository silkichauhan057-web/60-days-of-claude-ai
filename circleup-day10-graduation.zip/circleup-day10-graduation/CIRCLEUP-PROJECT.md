# CircleUp — Capstone Project Overview

> This document lives alongside the general 60-Day Claude AI Challenge documentation in this repository. It specifically covers CircleUp, the 10-day capstone project (Days 3–10 of the challenge).

## What it is

CircleUp is a mobile social app for joining interest-based communities ("circles"), sharing updates inside them, and commenting — built with React Native (Expo) and Firebase. It was designed, built, hardened, and launched over a structured 10-day sprint, following a PRD → architecture → build → QA → launch lifecycle.

## Live Demo

The app runs via Expo — clone the repo, run `npx expo start`, and open it in Expo Go on your phone. (A permanent EAS Update link can be added here once published.)

## The 10-Day Build, In Brief

| Day | Focus |
|---|---|
| 1–2 | Product requirements, architecture, database & API design (planning) |
| 3 | Dev environment, project scaffold, Firebase connection, "Hello World" |
| 4 | Authentication — signup, login, logout, persisted sessions |
| 5 | Circles — browse, create, join/leave, Firestore security rules |
| 6 | Posts & comments inside circles, required footer branding, MVP complete |
| 7 | UI/UX polish — design system, loading/empty/error states, EAS deployment |
| 8 | QA pass — found and fixed a real security vulnerability, offline handling, crash resilience |
| 9 | Launch readiness — README, LICENSE, environment variables, release checklist |
| 10 | Final review, portfolio materials, v1.0.0 release |

## Why It's a Good Portfolio Piece

This isn't a tutorial clone — it's a full-stack mobile app with a real, documented security fix (Day 8), production-style error handling, and a genuine launch process, all built and reasoned through in public across this repository.

See `challenge-retrospective.md` in this repo for the full day-by-day story, and `future-scope.md` for where this project goes next.
