# CircleUp — Future Scope

How this specific project could realistically evolve, based on what's already built.

## Next 3 Months: Solidify the Core

The MVP proves the concept works; this phase makes it trustworthy and pleasant to actually use daily.

- **Media in posts** — Firebase Storage integration so posts can include images, not just text. This is the single highest-impact feature missing from a "social" app.
- **Profile pictures** — currently users only have a name/email; avatars (even simple initials-based ones, then real uploads) make the app feel human.
- **Pagination** — `subscribeToAllCircles` and `subscribeToCirclePosts` currently fetch everything with no limit. Add `limit()` + "load more" before this becomes a real cost/performance problem.
- **Push notifications** — via `expo-notifications` (free) for new posts/comments in circles a user has joined.
- **Basic search** — find circles by name, since Browse is currently just an unfiltered list.
- **Custom app icon and splash screen** — the last piece of "this looks like a real app" polish.

## Next 6 Months: Depth & Trust

Once the core loop is solid, this phase adds the features that make a community app actually work as a community.

- **Moderation tools** — circle creators can remove a post/comment or remove a member; report functionality for abuse.
- **Direct messaging** between members of a shared circle.
- **Events** — circles can post scheduled events (time/location), members can RSVP; a natural extension of the existing "posts" data model.
- **Automated testing** — Jest + React Native Testing Library for the service layer (`authService`, `circleService`, `postService`) and critical screens; currently zero test coverage, which is fine for a 10-day capstone but not for anything longer-lived.
- **CI/CD** — GitHub Actions running tests and an EAS preview build on every pull request.
- **Analytics** — lightweight, privacy-respecting usage tracking (e.g., which circles get created vs. actually used) to inform what to build next.

## Next 12 Months: Product Maturity

- **TypeScript migration** — the codebase is small enough now to convert incrementally; waiting longer only makes it harder.
- **Admin/moderation dashboard** — a simple web panel (could reuse Firebase Auth) for managing reported content across circles.
- **Recommendation logic** — surface circles a user might like based on their existing memberships, rather than one flat unsorted list.
- **Public circle discovery page** (web) — a lightweight marketing/discovery surface outside the app, driving install growth.
- **Scale review** — revisit the Firestore data model and rules under real usage patterns; the current schema (flat `posts`/`comments` collections filtered by `circleId`/`postId`) is simple and correct for MVP scale but should be re-evaluated once usage numbers exist.
