# CircleUp — Portfolio Materials

## Project Description (short — for a portfolio site or LinkedIn "Featured")

CircleUp is a React Native + Firebase mobile app for joining interest-based communities, sharing updates, and commenting — built end-to-end over a structured 10-day sprint, including a real security vulnerability found and fixed during QA.

## Project Description (long — for a case study page or GitHub README)

CircleUp is a full-stack mobile social app that lets users create and join interest-based "circles," post live updates inside them, and comment on posts — all backed by Firebase Authentication and Firestore. It was built in 10 structured days following a real software development lifecycle: requirements and architecture first, then a working foundation, core features, UI/UX polish, a dedicated QA and security-hardening pass, and a final production launch checklist. During the Day 8 QA review, a genuine authorization vulnerability was identified — Firestore rules allowed any authenticated user to edit any circle's data or impersonate other users when posting — and was fixed by rewriting the security rules to enforce ownership and authorship at the database level, not just in the UI.

## Resume Bullet Points

- Built and shipped CircleUp, a full-stack React Native mobile app (Firebase Auth + Firestore) supporting real-time social features across a 10-day structured development sprint
- Identified and remediated a Firestore authorization vulnerability allowing data tampering and user impersonation, rewriting security rules to enforce field-level ownership checks
- Implemented production-readiness practices including environment variable hygiene, offline-state handling, app-wide crash recovery, and comprehensive loading/empty/error UI states
- Designed and built a reusable component/design-system layer (theme tokens, shared Button/Input/Card components) reducing UI inconsistency and duplicate styling code
- Refactored duplicated data-fetching logic across screens into a shared custom React hook, improving maintainability

## Interview Talking Points

**"Tell me about a bug or issue you found and fixed."**
On Day 8 of building CircleUp, I did a deliberate security review of my Firestore rules before treating the app as launch-ready — instead of just checking that features worked, I asked "what could a malicious authenticated user do that the UI doesn't prevent?" I found that my rules technically allowed any logged-in user to edit any circle's data, or set an arbitrary `authorId` on a new post/comment — meaning someone could impersonate another user. I fixed it by rewriting the rules to check `request.resource.data.authorId == request.auth.uid` on writes, and to restrict circle edits to the creator, using Firestore's `diff().affectedKeys()` to allow non-creators to *only* modify their own membership status.

**"How do you approach production readiness?"**
I treat it as a distinct phase, not something that happens automatically. For CircleUp, that meant a dedicated Day 8 QA pass separate from feature-building — looking specifically for silent failures (actions that fail with no user feedback), missing offline handling, and crash resilience — followed by a Day 9 launch pass covering documentation, licensing, and getting secrets out of source control.

**"Describe your process for building something end-to-end."**
I followed a structured lifecycle: requirements and system design first, then foundation/scaffolding, then core features in dependency order (auth before anything that needs a logged-in user), then a dedicated polish pass, then QA, then launch — rather than building features and polish simultaneously.

## Demo Script (2–3 minutes)

1. **Open on Login screen.** "This is CircleUp — a social app for joining interest-based communities." Sign up with a new account.
2. **Land on Browse tab.** "Auth is handled through Firebase, with sessions persisted across app restarts." Show the empty/populated circle list.
3. **Create a circle.** Tap Create tab, fill in name/description, submit. "Firestore security rules enforce that only I, as the creator, can edit this circle later — that's not just a UI restriction, it's enforced at the database level."
4. **Post and comment.** Join a circle, post an update, open it, add a comment. "Everything here is live — Firestore's real-time listeners mean other members see this instantly, no refresh needed."
5. **Show the offline banner.** Turn on Airplane Mode briefly. "The app also handles network loss gracefully instead of failing silently."
6. **Close on the Profile tab**, pointing out the required challenge-attribution footer, and mention the GitHub repo for anyone who wants to see the code or the security fix specifically.
