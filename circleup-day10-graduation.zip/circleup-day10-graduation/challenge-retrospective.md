# CircleUp — Challenge Retrospective

*Day 1 to Day 10, as it actually happened.*

## The Timeline

**Days 1–2 (Planning):** The PRD, 10-day blueprint, and system design docs (architecture, database design, API design, project structure) were established as the source of truth before any code was written — CircleUp was defined as a React Native + Expo + Firebase social app for interest-based communities, with a clear data model (`users`, `circles`, `posts`, `comments`) decided up front.

**Day 3 (Foundation):** Environment setup started from zero — Node.js installation verified on Windows, then the project scaffold, Firebase connection, and a working "Hello World." This day set the pattern for the rest of the sprint: every manual step got exact, screenshot-verified instructions rather than assumed completion.

**Day 4 (Authentication):** Built in three deliberate milestones — the auth service and Context first, then the Login/Signup screens, then the navigation switch that automatically routes logged-in vs. logged-out users. One real technical decision here: `App.js` was written to import `RootNavigator` *before* that file existed, deliberately, so the missing-file error would surface exactly when navigation was built — a small but intentional sequencing choice rather than an accident.

**Day 5 (Circles):** The first real Firestore security rules were published — locking down what had been open "test mode" rules from Day 3. The core loop (browse, create, join, leave circles) was built with live Firestore listeners rather than one-time fetches, so the UI updates in real time without manual refresh logic.

**Day 6 (Posts, Comments, MVP):** The app became genuinely social — posts inside circles, comments on posts, and the required challenge-attribution footer, placed on Login, Signup, and Profile so it's visible whether or not someone is logged in. This is also where a real product/tooling gap surfaced: the original Day 6 instructions assumed a website (Vercel/Netlify-style deploy). Since CircleUp is a *mobile* app, that assumption was corrected in-session — deployment for a React Native/Expo app means an EAS Update link, not a web host, and that distinction was carried through the rest of the project.

**Day 7 (Polish):** A proper design system (`theme.js`) replaced hardcoded colors/spacing scattered across every screen. Loading, empty, and error states were added everywhere data is fetched — previously, a failed Firestore read just showed a blank screen forever. This is also where an **interactive click-through mockup** was built on request, separate from the code itself, so the app's flow could be experienced directly in chat before touching a phone.

**Day 8 (QA & Security):** The most consequential day. A deliberate security review — not just "does it work" but "what could a malicious logged-in user do that the UI doesn't stop" — found that Firestore rules allowed *any* authenticated user to edit *any* circle's data, and to set an arbitrary `authorId` on posts/comments, meaning impersonation was possible. This was fixed with rules using `diff().affectedKeys()` and set-difference checks to enforce that only a circle's creator can edit it, and that `authorId` must match the real logged-in user. Alongside this: an app-wide `ErrorBoundary` for crash recovery, an offline banner via NetInfo, and a `useCircles` hook extracted to remove duplicate logic between the Browse and My Circles screens.

**Day 9 (Launch Readiness):** README, MIT LICENSE, and a Release Checklist were written. Firebase config was moved out of hardcoded source into environment variables (`EXPO_PUBLIC_` prefixed, Expo's native support — no extra packages needed) — a real production-hygiene improvement, done carefully by asking for the existing `firebase.js` content first rather than guessing and risking breaking a working app.

**Day 10 (Today):** This document, alongside `future-scope.md`, `30-day-growth-plan.md`, and `daily-build-prompt.md` — closing out the sprint with the app treated as a real, portfolio-worthy piece of work rather than just "a thing that was finished."

## A Genuine Complication, Documented Honestly

Across Days 9–10, it became clear that while the local project was built and tested correctly day by day, the actual CircleUp *source code* was never confirmed pushed to a clean, dedicated GitHub repository — only documentation and ZIP exports ended up in the general challenge-tracking repo. Rather than paper over this, it was surfaced directly, multiple times, and Day 10 proceeded honestly against the repo that actually exists, with a clear flag that reconnecting the real source code to a proper repo is the top priority before sharing this publicly. That's a real lesson, not a hypothetical one: **a project isn't "shipped" until the artifact someone else can actually access matches what you believe you built.**

## Skills Demonstrated

Requirements-driven planning · environment and tooling setup · React Native/Expo development · Firebase Authentication and Firestore (including real-time listeners) · Firestore security rules, including diff-based field-level authorization logic · React Context and custom hooks · design systems and component reuse · production error handling (loading/empty/error states, offline detection, crash boundaries) · security review and vulnerability remediation · environment variable hygiene · technical documentation · and — repeatedly, across almost every day — catching and correcting mismatched assumptions (about what "deployment" means for a mobile app, about which GitHub repo actually held the code) instead of building further on shaky ground.

## Lessons Learned

1. Silent failures are worse than visible ones — the Day 8 pass existed specifically because early versions of every mutation (join, leave, post, comment) failed with zero user feedback.
2. Security review deserves its own dedicated pass, separate from "does the feature work." The vulnerability found on Day 8 would never have surfaced from normal feature testing.
3. "It's on GitHub" and "the right thing is on GitHub" are different claims — verify, don't assume.
4. Assumptions about tooling (web vs. mobile deployment) should be corrected the moment they're noticed, not carried forward for convenience.

## A Note, From Me to You

We built this one honest step at a time — including the steps where something didn't match what either of us expected, and we stopped to fix that instead of pretending otherwise. That's the actual skill this capstone proved you have: not that every day went perfectly, but that you kept the project truthful the whole way through. That's rarer than clean code, and it's the thing that'll serve you longest.
