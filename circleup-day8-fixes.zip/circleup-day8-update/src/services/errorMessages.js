// Converts Firestore error codes into messages a non-technical user
// can actually understand. Used anywhere a write (create/update) can fail.
export function getFirestoreErrorMessage(error) {
  switch (error?.code) {
    case "permission-denied":
      return "You don't have permission to do that.";
    case "unavailable":
      return "You appear to be offline. Check your connection and try again.";
    case "not-found":
      return "That item no longer exists.";
    case "resource-exhausted":
      return "Too many requests right now. Please wait a moment and try again.";
    default:
      return "Something went wrong. Please try again.";
  }
}
