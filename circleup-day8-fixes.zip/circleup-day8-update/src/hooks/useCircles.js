import { useEffect, useState, useCallback } from "react";
import { subscribeToAllCircles } from "../services/circleService";

// Shared data-fetching logic for the Browse and My Circles screens.
// Both screens need the exact same live circles list, loading state,
// error state, and retry mechanism — this hook removes that duplication.
// Pass mineOnly=true to filter down to circles the given uid has joined.
export function useCircles(uid, mineOnly = false) {
  const [circles, setCircles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    setLoading(true);
    setError(null);
    const unsubscribe = subscribeToAllCircles(
      (data) => {
        setCircles(mineOnly ? data.filter((c) => c.memberIds?.includes(uid)) : data);
        setLoading(false);
      },
      (err) => {
        setError(err);
        setLoading(false);
      }
    );
    return unsubscribe;
  }, [uid, mineOnly, reloadKey]);

  const retry = useCallback(() => setReloadKey((k) => k + 1), []);

  return { circles, loading, error, retry };
}
