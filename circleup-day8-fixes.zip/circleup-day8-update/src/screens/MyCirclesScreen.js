import React from "react";
import { View, FlatList, Text, StyleSheet } from "react-native";
import CircleCard from "../components/CircleCard";
import LoadingSpinner from "../components/LoadingSpinner";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { useCircles } from "../hooks/useCircles";
import { useAuth } from "../context/AuthContext";
import { colors, spacing, typography } from "../constants/theme";

export default function MyCirclesScreen({ navigation }) {
  const { user } = useAuth();
  const { circles, loading, error, retry } = useCircles(user.uid, true);

  if (loading) return <LoadingSpinner label="Loading your circles..." />;
  if (error) return <ErrorState message="Couldn't load your circles. Check your connection and try again." onRetry={retry} />;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Circles</Text>
      <FlatList
        data={circles}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: spacing.lg }}
        renderItem={({ item }) => (
          <CircleCard
            circle={item}
            isMember={true}
            onPress={() => navigation.navigate("CircleDetail", { circleId: item.id })}
          />
        )}
        ListEmptyComponent={
          <EmptyState
            icon="people-outline"
            title="You haven't joined any circles yet"
            subtitle="Head to Browse to find one that fits you."
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md },
  title: { ...typography.title, color: colors.textPrimary, marginBottom: spacing.md },
});
