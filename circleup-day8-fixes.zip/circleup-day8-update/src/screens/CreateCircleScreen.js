import React, { useState } from "react";
import { View, Text, StyleSheet, ScrollView, KeyboardAvoidingView, Platform } from "react-native";
import Input from "../components/Input";
import Button from "../components/Button";
import { createCircle } from "../services/circleService";
import { getFirestoreErrorMessage } from "../services/errorMessages";
import { useAuth } from "../context/AuthContext";
import { colors, spacing, typography } from "../constants/theme";

const MAX_NAME_LENGTH = 60;
const MAX_DESCRIPTION_LENGTH = 280;

export default function CreateCircleScreen({ navigation }) {
  const { user } = useAuth();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleCreate = async () => {
    setErrorMsg("");
    const trimmedName = name.trim();
    const trimmedDesc = description.trim();

    if (!trimmedName || !trimmedDesc) {
      setErrorMsg("Please fill in both fields.");
      return;
    }
    if (trimmedName.length > MAX_NAME_LENGTH) {
      setErrorMsg(`Circle name must be under ${MAX_NAME_LENGTH} characters.`);
      return;
    }
    if (trimmedDesc.length > MAX_DESCRIPTION_LENGTH) {
      setErrorMsg(`Description must be under ${MAX_DESCRIPTION_LENGTH} characters.`);
      return;
    }

    setLoading(true);
    try {
      const circleId = await createCircle(trimmedName, trimmedDesc, user.uid);
      setName("");
      setDescription("");
      navigation.navigate("BrowseTab", {
        screen: "CircleDetail",
        params: { circleId },
      });
    } catch (error) {
      setErrorMsg(getFirestoreErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.title}>Create a Circle</Text>
        <Text style={styles.subtitle}>Start a space for people who share your interest.</Text>

        <Input
          label="Circle Name"
          placeholder="e.g. Weekend Hikers"
          value={name}
          onChangeText={setName}
          maxLength={MAX_NAME_LENGTH}
        />
        <Input
          label="Description"
          placeholder="What's this circle about?"
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={4}
          maxLength={MAX_DESCRIPTION_LENGTH}
          style={{ height: 100, textAlignVertical: "top" }}
        />

        {errorMsg ? <Text style={styles.errorBanner}>{errorMsg}</Text> : null}

        <Button title="Create Circle" onPress={handleCreate} loading={loading} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: spacing.lg, backgroundColor: colors.background },
  title: { ...typography.title, color: colors.textPrimary, marginBottom: 6 },
  subtitle: { fontSize: 14, color: colors.textSecondary, marginBottom: spacing.lg + 4 },
  errorBanner: { backgroundColor: colors.dangerBg, color: colors.dangerText, padding: 10, borderRadius: 8, marginBottom: spacing.sm + 6, fontSize: 13 },
});
