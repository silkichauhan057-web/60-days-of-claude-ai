import React, { useEffect, useState, useCallback } from "react";
import { View, Text, StyleSheet, FlatList } from "react-native";
import Button from "../components/Button";
import Input from "../components/Input";
import PostCard from "../components/PostCard";
import LoadingSpinner from "../components/LoadingSpinner";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { getCircleById, joinCircle, leaveCircle } from "../services/circleService";
import { createPost, subscribeToCirclePosts } from "../services/postService";
import { getFirestoreErrorMessage } from "../services/errorMessages";
import { useAuth } from "../context/AuthContext";
import { colors, spacing, typography } from "../constants/theme";

const MAX_POST_LENGTH = 500;

export default function CircleDetailScreen({ route, navigation }) {
  const { circleId } = route.params;
  const { user } = useAuth();
  const [circle, setCircle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState("");
  const [posts, setPosts] = useState([]);
  const [postsError, setPostsError] = useState(null);
  const [postText, setPostText] = useState("");
  const [posting, setPosting] = useState(false);
  const [postError, setPostError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  const loadCircle = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const data = await getCircleById(circleId);
      setCircle(data);
    } catch (err) {
      setLoadError(err);
    } finally {
      setLoading(false);
    }
  }, [circleId]);

  useEffect(() => {
    loadCircle();
  }, [loadCircle, reloadKey]);

  useEffect(() => {
    setPostsError(null);
    const unsubscribe = subscribeToCirclePosts(circleId, setPosts, (err) => setPostsError(err));
    return unsubscribe;
  }, [circleId]);

  const isMember = circle?.memberIds?.includes(user.uid);

  const handleJoin = async () => {
    setActionError("");
    setActionLoading(true);
    try {
      await joinCircle(circleId, user.uid);
      await loadCircle();
    } catch (err) {
      setActionError(getFirestoreErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handleLeave = async () => {
    setActionError("");
    setActionLoading(true);
    try {
      await leaveCircle(circleId, user.uid);
      await loadCircle();
    } catch (err) {
      setActionError(getFirestoreErrorMessage(err));
    } finally {
      setActionLoading(false);
    }
  };

  const handlePost = async () => {
    setPostError("");
    const trimmed = postText.trim();
    if (!trimmed) return;
    if (trimmed.length > MAX_POST_LENGTH) {
      setPostError(`Keep it under ${MAX_POST_LENGTH} characters (currently ${trimmed.length}).`);
      return;
    }
    setPosting(true);
    try {
      await createPost(circleId, user.uid, user.displayName || "Member", trimmed);
      setPostText("");
    } catch (err) {
      setPostError(getFirestoreErrorMessage(err));
    } finally {
      setPosting(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading circle..." />;
  if (loadError) {
    return (
      <ErrorState
        message="Couldn't load this circle. Check your connection and try again."
        onRetry={() => setReloadKey((k) => k + 1)}
      />
    );
  }
  if (!circle) return <EmptyState icon="alert-circle-outline" title="Circle not found" />;

  return (
    <FlatList
      style={styles.container}
      contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xl }}
      data={isMember ? posts : []}
      keyExtractor={(item) => item.id}
      keyboardShouldPersistTaps="handled"
      ListHeaderComponent={
        <View>
          <Text style={styles.name}>{circle.name}</Text>
          <Text style={styles.members}>
            {circle.memberIds?.length || 0} member{(circle.memberIds?.length || 0) === 1 ? "" : "s"}
          </Text>
          <Text style={styles.description}>{circle.description}</Text>

          {isMember ? (
            <Button title="Leave Circle" onPress={handleLeave} loading={actionLoading} variant="secondary" />
          ) : (
            <Button title="Join Circle" onPress={handleJoin} loading={actionLoading} />
          )}
          {actionError ? <Text style={styles.errorBanner}>{actionError}</Text> : null}

          {isMember ? (
            <View style={styles.postBox}>
              <Input
                placeholder="Share an update with this circle..."
                value={postText}
                onChangeText={setPostText}
                multiline
                numberOfLines={3}
                style={{ height: 80, textAlignVertical: "top" }}
                error={postError}
              />
              <Button title="Post" onPress={handlePost} loading={posting} />
            </View>
          ) : (
            <Text style={styles.joinPrompt}>Join this circle to see and share updates.</Text>
          )}

          {isMember && postsError ? (
            <Text style={styles.feedError}>Couldn't load the feed. Pull to refresh or check your connection.</Text>
          ) : null}

          {isMember && !postsError && posts.length > 0 ? <Text style={styles.feedTitle}>Circle Feed</Text> : null}
        </View>
      }
      renderItem={({ item }) => (
        <PostCard post={item} onPress={() => navigation.navigate("PostDetail", { postId: item.id })} />
      )}
      ListEmptyComponent={
        isMember && !postsError ? (
          <EmptyState icon="chatbubbles-outline" title="No posts yet" subtitle="Be the first to share something!" />
        ) : null
      }
    />
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  name: { ...typography.title, color: colors.textPrimary, marginBottom: 6 },
  members: { ...typography.caption, color: colors.textMuted, marginBottom: spacing.md },
  description: { fontSize: 15, color: colors.textSecondary, lineHeight: 22, marginBottom: spacing.lg },
  postBox: { marginTop: spacing.lg },
  joinPrompt: { marginTop: spacing.lg, fontSize: 13, color: colors.textMuted, textAlign: "center" },
  feedError: { fontSize: 12, color: colors.dangerText, textAlign: "center", marginTop: spacing.lg },
  feedTitle: { ...typography.subheading, color: colors.textPrimary, marginTop: spacing.lg, marginBottom: spacing.sm + 2 },
  errorBanner: { backgroundColor: colors.dangerBg, color: colors.dangerText, padding: 10, borderRadius: 8, marginTop: spacing.sm, fontSize: 12, textAlign: "center" },
});
