import React, { useEffect, useState, useCallback } from "react";
import { View, Text, StyleSheet, FlatList, KeyboardAvoidingView, Platform } from "react-native";
import Input from "../components/Input";
import Button from "../components/Button";
import LoadingSpinner from "../components/LoadingSpinner";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { getPostById, createComment, subscribeToPostComments } from "../services/postService";
import { getFirestoreErrorMessage } from "../services/errorMessages";
import { useAuth } from "../context/AuthContext";
import { colors, spacing, typography } from "../constants/theme";

const MAX_COMMENT_LENGTH = 300;

export default function PostDetailScreen({ route }) {
  const { postId } = route.params;
  const { user } = useAuth();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [comments, setComments] = useState([]);
  const [commentsError, setCommentsError] = useState(null);
  const [commentText, setCommentText] = useState("");
  const [posting, setPosting] = useState(false);
  const [commentError, setCommentError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);

  const loadPost = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const data = await getPostById(postId);
      setPost(data);
    } catch (err) {
      setLoadError(err);
    } finally {
      setLoading(false);
    }
  }, [postId]);

  useEffect(() => {
    loadPost();
  }, [loadPost, reloadKey]);

  useEffect(() => {
    setCommentsError(null);
    const unsubscribe = subscribeToPostComments(postId, setComments, (err) => setCommentsError(err));
    return unsubscribe;
  }, [postId]);

  const handleComment = async () => {
    setCommentError("");
    const trimmed = commentText.trim();
    if (!trimmed) return;
    if (trimmed.length > MAX_COMMENT_LENGTH) {
      setCommentError(`Keep it under ${MAX_COMMENT_LENGTH} characters (currently ${trimmed.length}).`);
      return;
    }
    setPosting(true);
    try {
      await createComment(postId, user.uid, user.displayName || "Member", trimmed);
      setCommentText("");
    } catch (err) {
      setCommentError(getFirestoreErrorMessage(err));
    } finally {
      setPosting(false);
    }
  };

  if (loading) return <LoadingSpinner label="Loading post..." />;
  if (loadError) {
    return (
      <ErrorState
        message="Couldn't load this post. Check your connection and try again."
        onRetry={() => setReloadKey((k) => k + 1)}
      />
    );
  }
  if (!post) return <EmptyState icon="alert-circle-outline" title="Post not found" />;

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <FlatList
        style={styles.container}
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xl }}
        data={comments}
        keyExtractor={(item) => item.id}
        keyboardShouldPersistTaps="handled"
        ListHeaderComponent={
          <View>
            <View style={styles.postCard}>
              <Text style={styles.author}>{post.authorName}</Text>
              <Text style={styles.postText}>{post.text}</Text>
            </View>
            <Text style={styles.commentsTitle}>Comments</Text>
            {commentsError ? (
              <Text style={styles.commentsErrorText}>Couldn't load comments. Check your connection.</Text>
            ) : null}
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.commentCard}>
            <Text style={styles.commentAuthor}>{item.authorName}</Text>
            <Text style={styles.commentText}>{item.text}</Text>
          </View>
        )}
        ListEmptyComponent={
          !commentsError ? (
            <EmptyState icon="chatbubble-ellipses-outline" title="No comments yet" subtitle="Start the conversation!" />
          ) : null
        }
        ListFooterComponent={
          <View style={styles.commentBox}>
            <Input
              placeholder="Write a comment..."
              value={commentText}
              onChangeText={setCommentText}
              error={commentError}
            />
            <Button title="Comment" onPress={handleComment} loading={posting} />
          </View>
        }
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  postCard: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.md,
  },
  author: { ...typography.bodyBold, color: colors.primary, marginBottom: 6 },
  postText: { fontSize: 16, color: colors.textPrimary, lineHeight: 22 },
  commentsTitle: { ...typography.subheading, color: colors.textPrimary, marginBottom: spacing.sm + 2 },
  commentsErrorText: { fontSize: 12, color: colors.dangerText, marginBottom: spacing.sm },
  commentCard: {
    backgroundColor: colors.surface,
    borderRadius: 10,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.borderLight,
  },
  commentAuthor: { fontSize: 12, fontWeight: "700", color: colors.textSecondary, marginBottom: 2 },
  commentText: { fontSize: 13, color: colors.textSecondary },
  commentBox: { marginTop: spacing.md },
});
