import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import Input from "../components/Input";
import Button from "../components/Button";
import Footer from "../components/Footer";
import { signIn, getAuthErrorMessage } from "../services/authService";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleLogin = async () => {
    setErrorMsg("");
    const trimmedEmail = email.trim();

    if (!trimmedEmail || !password) {
      setErrorMsg("Please enter your email and password.");
      return;
    }
    if (!EMAIL_REGEX.test(trimmedEmail)) {
      setErrorMsg("That email address doesn't look valid.");
      return;
    }

    setLoading(true);
    try {
      await signIn(trimmedEmail, password);
    } catch (error) {
      setErrorMsg(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <View>
          <Text style={styles.title}>Welcome back</Text>
          <Text style={styles.subtitle}>Log in to keep up with your circles.</Text>

          <Input
            label="Email"
            placeholder="jane@example.com"
            keyboardType="email-address"
            textContentType="emailAddress"
            autoComplete="email"
            returnKeyType="next"
            value={email}
            onChangeText={setEmail}
          />
          <Input
            label="Password"
            placeholder="Your password"
            secureTextEntry
            textContentType="password"
            autoComplete="password"
            returnKeyType="done"
            onSubmitEditing={handleLogin}
            value={password}
            onChangeText={setPassword}
          />

          {errorMsg ? (
            <Text style={styles.errorBanner} accessibilityRole="alert">
              {errorMsg}
            </Text>
          ) : null}

          <Button title="Log In" onPress={handleLogin} loading={loading} />

          <TouchableOpacity style={styles.linkWrapper} onPress={() => navigation.navigate("Signup")}>
            <Text style={styles.linkText}>
              New here? <Text style={styles.linkBold}>Create an account</Text>
            </Text>
          </TouchableOpacity>
        </View>

        <Footer />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, justifyContent: "space-between", padding: 24, backgroundColor: "#fafafa" },
  title: { fontSize: 26, fontWeight: "800", color: "#111827", marginBottom: 6 },
  subtitle: { fontSize: 14, color: "#6b7280", marginBottom: 28 },
  errorBanner: { backgroundColor: "#fef2f2", color: "#b91c1c", padding: 10, borderRadius: 8, marginBottom: 14, fontSize: 13 },
  linkWrapper: { marginTop: 20, alignItems: "center" },
  linkText: { color: "#6b7280", fontSize: 14 },
  linkBold: { color: "#2563eb", fontWeight: "700" },
});
