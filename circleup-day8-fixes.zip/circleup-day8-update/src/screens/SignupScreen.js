import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import Input from "../components/Input";
import Button from "../components/Button";
import Footer from "../components/Footer";
import { signUp, getAuthErrorMessage } from "../services/authService";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MIN_PASSWORD_LENGTH = 6;

export default function SignupScreen({ navigation }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSignup = async () => {
    setErrorMsg("");
    const trimmedName = name.trim();
    const trimmedEmail = email.trim();

    if (!trimmedName || !trimmedEmail || !password) {
      setErrorMsg("Please fill in all fields.");
      return;
    }
    if (!EMAIL_REGEX.test(trimmedEmail)) {
      setErrorMsg("That email address doesn't look valid.");
      return;
    }
    if (password.length < MIN_PASSWORD_LENGTH) {
      setErrorMsg(`Password must be at least ${MIN_PASSWORD_LENGTH} characters.`);
      return;
    }

    setLoading(true);
    try {
      await signUp(trimmedEmail, password, trimmedName);
    } catch (error) {
      setErrorMsg(getAuthErrorMessage(error));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <View>
          <Text style={styles.title}>Create your CircleUp account</Text>
          <Text style={styles.subtitle}>Join circles. Share updates. Meet your people.</Text>

          <Input
            label="Name"
            placeholder="Jane Doe"
            textContentType="name"
            autoComplete="name"
            returnKeyType="next"
            value={name}
            onChangeText={setName}
          />
          <Input
            label="Email"
            placeholder="jane@example.com"
            keyboardType="email-address"
            textContentType="emailAddress"
            autoComplete="email"
            returnKeyType="next"
            value={email}
            onChangeText={setEmail}
          />
          <Input
            label="Password"
            placeholder="At least 6 characters"
            secureTextEntry
            textContentType="newPassword"
            autoComplete="new-password"
            returnKeyType="done"
            onSubmitEditing={handleSignup}
            value={password}
            onChangeText={setPassword}
          />

          {errorMsg ? (
            <Text style={styles.errorBanner} accessibilityRole="alert">
              {errorMsg}
            </Text>
          ) : null}

          <Button title="Sign Up" onPress={handleSignup} loading={loading} />

          <TouchableOpacity style={styles.linkWrapper} onPress={() => navigation.navigate("Login")}>
            <Text style={styles.linkText}>
              Already have an account? <Text style={styles.linkBold}>Log in</Text>
            </Text>
          </TouchableOpacity>
        </View>

        <Footer />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, justifyContent: "space-between", padding: 24, backgroundColor: "#fafafa" },
  title: { fontSize: 26, fontWeight: "800", color: "#111827", marginBottom: 6 },
  subtitle: { fontSize: 14, color: "#6b7280", marginBottom: 28 },
  errorBanner: { backgroundColor: "#fef2f2", color: "#b91c1c", padding: 10, borderRadius: 8, marginBottom: 14, fontSize: 13 },
  linkWrapper: { marginTop: 20, alignItems: "center" },
  linkText: { color: "#6b7280", fontSize: 14 },
  linkBold: { color: "#2563eb", fontWeight: "700" },
});
