import React from "react";
import { View, FlatList, Text, StyleSheet } from "react-native";
import CircleCard from "../components/CircleCard";
import LoadingSpinner from "../components/LoadingSpinner";
import EmptyState from "../components/EmptyState";
import ErrorState from "../components/ErrorState";
import { useCircles } from "../hooks/useCircles";
import { useAuth } from "../context/AuthContext";
import { colors, spacing, typography } from "../constants/theme";

export default function BrowseCirclesScreen({ navigation }) {
  const { user } = useAuth();
  const { circles, loading, error, retry } = useCircles(user.uid, false);

  if (loading) return <LoadingSpinner label="Loading circles..." />;
  if (error) return <ErrorState message="Couldn't load circles. Check your connection and try again." onRetry={retry} />;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Browse Circles</Text>
      <FlatList
        data={circles}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: spacing.lg }}
        renderItem={({ item }) => (
          <CircleCard
            circle={item}
            isMember={item.memberIds?.includes(user.uid)}
            onPress={() => navigation.navigate("CircleDetail", { circleId: item.id })}
          />
        )}
        ListEmptyComponent={
          <EmptyState
            icon="compass-outline"
            title="No circles yet"
            subtitle="Be the first to create one from the Create tab!"
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: spacing.md },
  title: { ...typography.title, color: colors.textPrimary, marginBottom: spacing.md },
});
