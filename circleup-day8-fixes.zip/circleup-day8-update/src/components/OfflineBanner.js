import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet } from "react-native";
import NetInfo from "@react-native-community/netinfo";
import { colors } from "../constants/theme";

// Shows a persistent banner whenever the device loses connectivity,
// so failed writes (join/post/comment) make sense to the user instead
// of silently doing nothing.
export default function OfflineBanner() {
  const [isOffline, setIsOffline] = useState(false);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      setIsOffline(state.isConnected === false);
    });
    return unsubscribe;
  }, []);

  if (!isOffline) return null;

  return (
    <View style={styles.banner} accessibilityRole="alert" accessibilityLabel="You are offline">
      <Text style={styles.text}>You're offline — changes may not save until you reconnect.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  banner: { backgroundColor: colors.dangerBg, paddingVertical: 8, paddingHorizontal: 16 },
  text: { color: colors.dangerText, fontSize: 12, fontWeight: "600", textAlign: "center" },
});
