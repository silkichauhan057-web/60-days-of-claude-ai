import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Button from "./Button";
import { colors, spacing } from "../constants/theme";

// React error boundaries must be class components — there's no hook
// equivalent yet. This catches any render-time crash anywhere below it
// in the tree and shows a recovery screen instead of a blank/red crash.
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.error("CircleUp crashed:", error, info);
  }

  handleReset = () => {
    this.setState({ hasError: false });
  };

  render() {
    if (this.state.hasError) {
      return (
        <View style={styles.container}>
          <Text style={styles.title}>Something went wrong</Text>
          <Text style={styles.message}>
            CircleUp ran into an unexpected error. Try again — if it keeps happening, close and reopen the app.
          </Text>
          <View style={styles.buttonWrap}>
            <Button title="Try again" onPress={this.handleReset} variant="secondary" />
          </View>
        </View>
      );
    }
    return this.props.children;
  }
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center", padding: spacing.lg, backgroundColor: colors.background },
  title: { fontSize: 18, fontWeight: "700", color: colors.textPrimary, marginBottom: 8 },
  message: { fontSize: 13, color: colors.textSecondary, textAlign: "center" },
  buttonWrap: { width: "60%", marginTop: spacing.md },
});
