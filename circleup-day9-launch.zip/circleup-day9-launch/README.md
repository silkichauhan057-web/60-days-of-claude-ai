# CircleUp

A mobile social app for joining interest-based communities ("circles"), sharing updates, and commenting — built with React Native (Expo) and Firebase.

Built as a 10-day capstone project, developed with [Claude](https://claude.ai) by Anthropic as part of the AB Talks 60-Day Claude AI Challenge.

## Features

- **Authentication** — email/password sign up, login, and persisted sessions (Firebase Auth)
- **Circles** — browse all circles, create your own, join or leave any circle
- **Posts** — share updates inside circles you've joined, live-updating feed
- **Comments** — comment on any post, live-updating thread
- **Offline handling** — persistent banner when the device loses connectivity
- **Crash resilience** — app-wide error boundary with recovery UI
- **Production-hardened Firestore rules** — creators-only circle edits, author-verified posts/comments

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React Native (Expo) |
| Navigation | React Navigation (bottom tabs + native stack) |
| Backend | Firebase Authentication + Cloud Firestore |
| State | React Context (auth) + local component state |
| Network status | @react-native-community/netinfo |

All tools used are on free tiers — no paid services or API keys required to run this project.

## Project Structure

```
circleup/
├── App.js
├── app.json
├── .env.example
├── src/
│   ├── components/       # Button, Input, Cards, EmptyState, ErrorState, LoadingSpinner, Footer, ErrorBoundary, OfflineBanner
│   ├── constants/         # theme.js — colors, spacing, typography tokens
│   ├── context/           # AuthContext.js
│   ├── hooks/             # useCircles.js
│   ├── navigation/        # RootNavigator, AuthNavigator, AppNavigator, stack navigators
│   ├── screens/           # Login, Signup, Browse, MyCircles, CreateCircle, CircleDetail, PostDetail, Home/Profile
│   └── services/          # firebase.js, authService.js, circleService.js, postService.js, errorMessages.js
└── assets/
```

## Getting Started

### Prerequisites

- [Node.js](https://nodejs.org) (LTS version)
- A free [Firebase](https://console.firebase.google.com) project with Authentication (Email/Password) and Firestore enabled
- The [Expo Go](https://expo.dev/go) app on your phone (for local testing)

### Setup

1. Clone this repository:
   ```
   git clone https://github.com/yourusername/circleup.git
   cd circleup
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Copy `.env.example` to a new file named `.env` and fill in your own Firebase project's config values (found in Firebase Console → Project Settings → General → Your apps):
   ```
   cp .env.example .env
   ```

4. Publish the Firestore security rules found in `FIRESTORE_RULES.txt` (or the Release Checklist doc) to your Firebase project's Firestore Rules tab.

5. Start the development server:
   ```
   npx expo start
   ```

6. Scan the QR code with Expo Go on your phone, or press `a` / `i` for an Android/iOS emulator.

## License

MIT — see [LICENSE](./LICENSE) for details.

## Author

**Silki Chauhan** — B.Tech Computer Science student, building toward AI/software engineering roles.
