# CircleUp — Release Checklist

Consolidated from Days 3–9. Use this as a final pre-launch sanity check.

## Security
- [x] Firestore rules published (Day 9 hardened version — creators-only circle edits, author-verified posts/comments)
- [x] No hardcoded secrets in source after applying Milestone 3 (Firebase config now in `.env`, gitignored)
- [x] `.env` confirmed present in `.gitignore` (not pushed to GitHub)

## Core Functionality
- [x] Sign up / log in / log out
- [x] Browse circles, create a circle, join/leave
- [x] Post an update inside a joined circle
- [x] Comment on a post
- [x] Required footer visible ("Built with Claude as part of the AB Talks 60-Day Claude AI Challenge.")

## Reliability
- [x] Loading states on every data screen
- [x] Empty states on every list
- [x] Error states with retry on every data screen
- [x] Offline banner
- [x] App-wide crash recovery (Error Boundary)
- [x] Form validation before hitting Firebase (email format, password length, character limits)

## Documentation
- [x] README with setup instructions
- [x] LICENSE (MIT)
- [x] `.env.example` for anyone cloning the repo
- [ ] Screenshots in README (add your own once you have a few good ones)

## Still Manual / Your Call
- [ ] Confirm `app.json` name/description updated (Milestone 4 — do this by hand)
- [ ] Custom app icon/splash screen (optional polish, not a blocker)
- [ ] Final GitHub repo push with today's changes
- [ ] Final EAS Update publish so the live demo matches local code

## Known, Accepted Limitations (fine for a portfolio/demo project)
- No pagination on circle/post lists — fine at demo scale, would need `limit()` + cursor-based loading for real scale
- No image uploads (posts are text-only) — out of scope for this capstone
- No push notifications — out of scope for this capstone
- No automated test suite — manual testing only, appropriate for a 10-day solo capstone
